import React from "react";
import Presentation from "./Presentation.jsx";

export default function App() {
  return (
    <div className="app-root">
      <Presentation />
    </div>
  );
}
